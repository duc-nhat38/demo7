
<div class="">
    <i class="fas fa-user-shield"></i><b><?= $_SESSION["customer"]["userName"] ?></b>   
</div>
<div><a href="/admin">Thống kê</a></div>
<div><a href="/UserManagement">Quản lý người dùng</a></div>
<div><a href="/ProductManagement">Quản lý sản phẩm</a></div>
<div><a href="">Quản lý đơn hàng</a></div>
<div><a href="">Quản lý nhân viên</a></div>
<div><a href="/logout">Đăng xuất</a></div>