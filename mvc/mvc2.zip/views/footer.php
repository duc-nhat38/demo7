<div id="company">
    <h4>CÔNG TY CỔ PHẦN LAPTOP STORE </h4>
    <p>Địa chỉ : 175 Xuân Diệu - TP Huế</p>
    <div>
    <a href="" title="Email"><i class="fas fa-envelope"></i></a>
    <a href="" title="Facebook"><i class="fab fa-facebook-square"></i></a>
    <a href="" title="Youtube"><i class="fab fa-youtube-square"></i></a>
    </div>
</div>

<div id="support">
 <h4>HỖ TRỢ KHÁCH HÀNG</h4>
 <p>Tư vấn mua hàng (Miễn phí)</p>
 <p><b>0961694997</b></p>
 <p>Góp ý, khiếu nại dịch vụ (8h00-22h00)</p>
 <p><b>0961694997</b></p>
</div>
<div id="support_pay">
    <h4>HỖ TRỢ THANH TOÁN</h4>
    <img src="public/images/visa4.jpg" alt="">
    <img src="public/images/master2.jpg" alt="">
    <img src="public/images/tragop.jpg" alt="">
</div>